package com.bhavesh.app.EmployeeCRUD.dao;

import java.util.List;

import com.bhavesh.app.EmployeeCRUD.entity.Employee;

public interface EmployeeDAO {

	public boolean registerEmployee(Employee emp);
	public boolean deleteEmployee(int empId);
	public Employee getEmployeeDetails(int empId);
	public Employee updateEmployee(Employee emp);
	public List<Employee> getEmployees();
	
}
