package com.bhavesh.app.EmployeeCRUD.dao;

import java.util.List;

import com.bhavesh.app.EmployeeCRUD.entity.Employee;

public class EmployeeDAOImpl implements EmployeeDAO {

	@Override
	public boolean registerEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteEmployee(int empId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Employee getEmployeeDetails(int empId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> getEmployees() {
		// TODO Auto-generated method stub
		return null;
	}

}
