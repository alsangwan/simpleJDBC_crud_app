package com.bhavesh.app.EmployeeCRUD;

import java.util.List;

import com.bhavesh.app.EmployeeCRUD.dao.AddressDAO;
import com.bhavesh.app.EmployeeCRUD.dao.AddressDAOImpl;
import com.bhavesh.app.EmployeeCRUD.entity.EmpAddress;

public class App 
{
    public static void main( String[] args )
    {
       
    	//EmpAddress addr = new EmpAddress(0, "Noida", "Uttar Pradesh", 321345);
    	
    	AddressDAO dao = new AddressDAOImpl();
    	
    	/*if(dao.addNewAddress(addr))
    		System.out.println("New Address added successfully..!");
    	else
    		System.out.println("Something went wrong...!");
    	*/
    	
    	/*EmpAddress addr = dao.getAddress(150);
    	
    	if(addr != null)
    		System.out.println(addr);
    	else
    		System.out.println("Address not found on this Address_ID");
    	*/
    	EmpAddress addr = dao.getAddress(122);
    	System.out.println(addr);
    	
    	addr.setPincode(111333);
    	
    	dao.updateAddress(addr);
    	
    	dao.deleteAddress(1001);
    	
    	List<EmpAddress> addresses = dao.getAllAddresses();
    	
    	for(EmpAddress address : addresses) {
    		System.out.println(address);
    	}
    }
}
