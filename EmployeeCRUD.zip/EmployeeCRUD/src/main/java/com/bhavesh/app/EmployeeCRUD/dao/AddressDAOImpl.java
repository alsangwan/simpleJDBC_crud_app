package com.bhavesh.app.EmployeeCRUD.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.bhavesh.app.EmployeeCRUD.entity.EmpAddress;

public class AddressDAOImpl implements AddressDAO{

	private static final String URL = "jdbc:oracle:thin:@localhost:1521:xe";
	private static final String username = "system";
	private static final String password = "root";
	private String driverClassName = "oracle.jdbc.driver.OracleDriver";
	
	Connection conn = null;
	Statement stmt = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	
	@Override
	public boolean addNewAddress(EmpAddress addr) {
		
		boolean added = false;
		
		try {
			// 1. Load the driver and create the connection object
			
			Class.forName(driverClassName);
			conn = DriverManager.getConnection(URL, username, password);
			
			//2. Create the statement object to be executed on DB 
			
			String query = "insert into emp_addresses (addr_city, addr_state, addr_pincode) values (?,?,?)";
			pst = conn.prepareStatement(query);

			pst.setString(1, addr.getCity());
			pst.setString(2, addr.getState());
			pst.setInt(3, addr.getPincode());
			
			//3. Perform insert data
			int rows = pst.executeUpdate();
			
			//4. collect the result and close the connection
			if(rows > 0)
				added = true;
			
			pst.close();
			conn.close();
		
		}catch(ClassNotFoundException e) {
			System.out.println("Could not load the driver class...");
		}catch(SQLException e) {
			System.out.println("Problem with SQL statement/query..");
			e.printStackTrace();
		}
		return added;
	}

	@Override
	public EmpAddress getAddress(int id) {
		EmpAddress addr = null;
		try {
			Class.forName(driverClassName);
			conn = DriverManager.getConnection(URL, username, password);
			String query = "select * from emp_addresses WHERE addr_id=?";
			pst = conn.prepareStatement(query);
			pst.setInt(1, id);
			
			rs = pst.executeQuery();
			
			if(rs.next()) {
				addr = new EmpAddress();
				addr.setId(rs.getInt(1));
				addr.setCity(rs.getString(2));
				addr.setState(rs.getString(3));
				addr.setPincode(rs.getInt(4));
			}
			
			rs.close();
			pst.close();
			conn.close();
			
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return addr;
	}

	@Override
	public List<EmpAddress> getAllAddresses() {
		
		List<EmpAddress> addresses = new ArrayList<EmpAddress>();
		try {
			Class.forName(driverClassName);
			conn = DriverManager.getConnection(URL, username, password);
			String query = "select * from emp_addresses";
			stmt = conn.createStatement();
			
			
			rs = stmt.executeQuery(query);
			
			while(rs.next()) {
				EmpAddress addr = new EmpAddress();
				addr.setId(rs.getInt(1));
				addr.setCity(rs.getString(2));
				addr.setState(rs.getString(3));
				addr.setPincode(rs.getInt(4));
				
				addresses.add(addr);
			}
			
			rs.close();
			stmt.close();
			conn.close();
			
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return addresses;
	}

	public EmpAddress updateAddress(EmpAddress addr) {
		EmpAddress updatedAddress = null;
		
		try {
			
			Class.forName(driverClassName);
			conn = DriverManager.getConnection(URL, username, password); 
			
			String query = "update emp_addresses SET addr_city=?, addr_state=?, addr_pincode=? where addr_id=?";
			pst = conn.prepareStatement(query);

			pst.setString(1, addr.getCity());
			pst.setString(2, addr.getState());
			pst.setInt(3, addr.getPincode());
			pst.setInt(4, addr.getId());
			
			int rows = pst.executeUpdate();
			
			pst.close();
			conn.close();
			
			if(rows > 0)
				updatedAddress = getAddress(addr.getId());
			
			
		
		}catch(ClassNotFoundException e) {
			System.out.println("Could not load the driver class...");
		}catch(SQLException e) {
			System.out.println("Problem with SQL statement/query..");
			e.printStackTrace();
		}
		
		return updatedAddress;
	}
	
	public boolean deleteAddress(int addr_id) {
		System.out.println("Inside the delete method..");
		boolean addressDeleted = false;
		try {
			
			Class.forName(driverClassName);
			conn = DriverManager.getConnection(URL, username, password); 
			System.out.println("Connection created...");
			String query = "delete from emp_addresses where addr_id=?";
			pst = conn.prepareStatement(query);
			System.out.println("Statement preprated..");
			pst.setInt(1, addr_id);
			
			int rows = pst.executeUpdate();
			System.out.println("Record deleted...");
			pst.close();
			conn.close();
			
			if(rows > 0)
				addressDeleted = true;
		
		}catch(ClassNotFoundException e) {
			System.out.println("Could not load the driver class...");
		}catch(SQLException e) {
			System.out.println("Problem with SQL statement/query..");
			e.printStackTrace();
		}
		return addressDeleted;
	}
}
