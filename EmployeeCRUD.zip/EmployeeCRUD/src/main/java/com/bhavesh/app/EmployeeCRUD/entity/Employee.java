package com.bhavesh.app.EmployeeCRUD.entity;

public class Employee {

	private int empId;
	private String name;
	private int salary;
	private String desg;
	private String email;
	private int addr_id;
	
	public Employee() {}

	public Employee(int empId, String name, int salary, String desg, String email, int addr_id) {
		super();
		this.empId = empId;
		this.name = name;
		this.salary = salary;
		this.desg = desg;
		this.email = email;
		this.addr_id = addr_id;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getDesg() {
		return desg;
	}

	public void setDesg(String desg) {
		this.desg = desg;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getAddr_id() {
		return addr_id;
	}

	public void setAddr_id(int addr_id) {
		this.addr_id = addr_id;
	}
	
	public String toString() {
		return empId+"|"+name;
	}
}
