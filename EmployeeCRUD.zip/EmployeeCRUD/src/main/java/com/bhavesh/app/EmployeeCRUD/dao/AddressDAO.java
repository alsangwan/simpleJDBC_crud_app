package com.bhavesh.app.EmployeeCRUD.dao;

import com.bhavesh.app.EmployeeCRUD.entity.EmpAddress;
import java.util.List;

public interface AddressDAO {

	public boolean addNewAddress(EmpAddress addr) ;
	public EmpAddress getAddress(int id);
	public List<EmpAddress> getAllAddresses();
	public EmpAddress updateAddress(EmpAddress addr);
	public boolean deleteAddress(int addr_id);
}
